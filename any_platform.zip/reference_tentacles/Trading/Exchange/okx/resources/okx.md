Okx is a basic RestExchange adaptation for OKX exchange. 
