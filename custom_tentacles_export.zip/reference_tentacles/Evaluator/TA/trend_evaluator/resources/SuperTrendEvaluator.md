SuperTrendEvaluator is a trend-following indicator based on Average True Range [ATR](https://www.tradingview.com/scripts/averagetruerange/). The calculation of its single line combines trend detection and volatility. It can be used to detect changes in trend direction and to position stops.

Evaluates -1 on an upwards trend and 1 if the trend is downwards.
