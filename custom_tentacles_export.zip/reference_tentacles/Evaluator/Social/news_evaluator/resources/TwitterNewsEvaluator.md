Triggers when a new tweet appears from a Twitter account in TwitterNewsEvaluator.json.

If the evaluation of any given tweet is significant enough, triggers strategies re-evaluation. Otherwise 
acts as a background evaluator.