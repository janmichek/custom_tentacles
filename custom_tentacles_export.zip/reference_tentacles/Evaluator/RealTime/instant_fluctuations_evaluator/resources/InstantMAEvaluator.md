Uses a [moving average](https://www.investopedia.com/terms/m/movingaverage.asp) 
computed on close prices to set its evaluation. 

Will trigger an evaluation when the current close price is beyond the given price threshold applied on
the latest moving average value.

Triggers on each new candle and price change. 
