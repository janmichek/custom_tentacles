Ndax is a basic RestExchange adaptation for Ndax exchange. 
