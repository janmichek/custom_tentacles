Huobi is a basic RestExchange adaptation for Huobi exchange. 
