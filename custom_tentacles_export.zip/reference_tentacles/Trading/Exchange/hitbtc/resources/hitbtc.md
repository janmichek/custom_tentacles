Hitbtc is a basic RestExchange adaptation for Hitbtc exchange. 
