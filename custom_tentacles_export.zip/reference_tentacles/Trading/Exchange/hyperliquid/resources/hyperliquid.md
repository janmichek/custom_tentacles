Hyperliquid is a basic RestExchange adaptation for Hyperliquid exchange. 
