UpbitExchange is a basic RestExchange adaptation for WavesExchange exchange. 
