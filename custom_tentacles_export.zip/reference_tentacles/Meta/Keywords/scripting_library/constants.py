import octobot_commons.enums as common_enums


DEFAULT_TIMEFRAME = common_enums.TimeFrames.ONE_HOUR
PRICE_UPDATE_TIME_FRAME = common_enums.TimeFrames.FIFTEEN_MINUTES
